package com.zfl.launcher.ui.home

import com.zfl.launcher.data.PageWidgetEntry
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.center
import androidx.compose.ui.input.pointer.PointerEvent
import com.zfl.launcher.data.AppEntry
import com.zfl.launcher.data.DEFAULT_DOCK_CAPACITY
import com.zfl.launcher.data.DropPosition
import com.zfl.launcher.data.FolderEntry
import com.zfl.launcher.data.GridSpec
import com.zfl.launcher.data.HomeEntry
import com.zfl.launcher.data.HomeState
import com.zfl.launcher.data.PlaceholderEntry
import com.zfl.launcher.data.boundedCell
import com.zfl.launcher.data.itemAtCell
import com.zfl.launcher.data.packCells
import com.zfl.launcher.data.Span
import com.zfl.launcher.data.span
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Apps on one page of an open folder. */
internal val FOLDER_PAGE_SIZE: Int = GridSpec.Folder.cellCount

/** Where a dragged item was picked up. */
enum class DragSource { Page, Dock, Folder, Library }

/** An item being dragged. [pointer] is in window coordinates. */
@Stable
class DragSession(
    val entry: HomeEntry,
    val source: DragSource,
    /** Finger position relative to the icon's top-left corner, so the icon doesn't jump. */
    val touchOffset: Offset,
    val start: Offset,
    /** Size of the picked-up icon or widget card, in px. */
    val itemSize: Size,
) {
    var pointer: Offset by mutableStateOf(start)
    /** False while it's only a long-press (menu open); true once the finger moved. */
    var active: Boolean by mutableStateOf(false)

    /**
     * The point that decides where the item goes: the visual center of a dragged icon, so
     * putting it on top of another icon works no matter where the icon was grabbed.
     * Widgets keep following the finger, since their card spans several cells.
     */
    val hotspot: Offset
        get() = if (entry is PageWidgetEntry) pointer else pointer - touchOffset + itemSize.center
}

/** Root-level drag tracking, exact cell previews, folder merging and edge page flips. */
@Stable
class DragController(
    private val scope: CoroutineScope,
    private val slopPx: Float,
    private val edgePx: Float,
    private val callbacks: Callbacks,
    pageSwipePx: Float = slopPx,
) {
    private val pointers = DragPointers(slopPx, pageSwipePx)
    interface Callbacks {
        /** The finger moved after a long-press: close the menu and enter edit mode. */
        fun onDragActivated()
        fun onDrop(id: String, position: DropPosition)
        fun onFlipPage(page: Int)
        /** The finger left the open folder: close it and keep dragging on the home screen. */
        fun onLeaveFolder()
    }

    var session: DragSession? by mutableStateOf(null)
        private set

    /** Where the item lands if released now; null = back to where it came from. */
    var target: DropPosition? by mutableStateOf(null)
        private set

    /** Item under the finger that would become (or receive) a folder. */
    var mergeCandidate: String? by mutableStateOf(null)
        private set
    var mergeArmed: Boolean by mutableStateOf(false)
        private set

    // Inputs kept up to date by the screen.
    var state: HomeState = HomeState()
    var pageMap: HomePages = HomePages(1, today = false, library = false)
    /** Home page under the finger; -1 for the Today page. */
    var currentPage: Int = 0
    var screenWidth: Float = 0f
    /** Right-to-left layout: columns, dock slots and page flips are mirrored on screen. */
    var rtl: Boolean = false
    var openFolder: FolderEntry? = null
    var pageGrid: GridGeometry? = null
    /** Hit testing supplied by the visible App Library grid, in window coordinates. */
    val libraryTargets: MutableMap<Any, (Offset) -> DropPosition.Library?> = linkedMapOf()
    var dockBounds: Rect? = null
    /** Dock slots chosen in settings. */
    var dockCapacity: Int = DEFAULT_DOCK_CAPACITY
    var folderPanel: Rect? = null
    var folderGrid: GridGeometry? = null
    var folderPage: Int = 0

    private var mergeJob: Job? = null
    private var reorderJob: Job? = null
    /** Latest slot under the finger; icons make room there after a short dwell. */
    var pendingTarget: DropPosition? by mutableStateOf(null)
        private set
    private var restPoint: Offset = Offset.Zero
    private var edgeJob: Job? = null
    private var leaveFolderJob: Job? = null
    private var dropOrigin: Pair<String, Offset>? = null

    val isDragging: Boolean get() = session?.active == true
    val draggedId: String? get() = session?.takeIf { it.active }?.entry?.id

    /** Long-press in normal mode: remember the item; dragging begins only if the finger moves. */
    fun prepare(entry: HomeEntry, source: DragSource, iconBounds: Rect, pointer: Offset) {
        pointers.bind(pointer)
        session = DragSession(entry, source, pointer - iconBounds.topLeft, pointer, iconBounds.size)
    }

    /** Edit mode: the finger already moved past the touch slop, so drag right away. */
    fun start(entry: HomeEntry, source: DragSource, iconBounds: Rect, pointer: Offset) {
        pointers.bind(pointer)
        session = DragSession(entry, source, pointer - iconBounds.topLeft, pointer, iconBounds.size).also { it.active = true }
        target = initialTarget(entry, source)
    }

    /** Root pointer handler (Initial pass). Consumes events while a drag is in progress. */
    fun onPointerEvent(event: PointerEvent) {
        pointers.observe(event)
        val s = session ?: return
        val change = pointers.primary() ?: run { cancel(); return }
        if (!change.pressed) {
            if (s.active) drop(s) else reset()
            return
        }
        val swipe = pointers.swipe(s.active && openFolder == null)
        if (pointers.hasSecondary) cancelEdgeFlip()
        if (swipe != 0) {
            val direction = if (rtl) -swipe else swipe
            pageMap.dragNeighbor(currentPage, direction, s.entry is AppEntry)?.let { next ->
                reorderJob?.cancel()
                pendingTarget = null
                target = null
                setMerge(null)
                pageGrid = null
                currentPage = next
                callbacks.onFlipPage(next)
            }
        }
        s.pointer = change.position
        if (!s.active && (change.position - s.start).getDistance() > slopPx) {
            s.active = true
            target = initialTarget(s.entry, s.source)
            if (s.source == DragSource.Library) {
                currentPage = state.pages.lastIndex
                // Wait for the destination page to be laid out after leaving the library.
                pageGrid = null
            }
            callbacks.onDragActivated()
        }
        if (s.active) updateTarget(s)
        change.consume()
    }

    /** One-shot: where the item was released, so its new slot can animate from there. */
    fun takeDropOrigin(id: String): Offset? =
        dropOrigin?.takeIf { it.first == id }?.second?.also { dropOrigin = null }

    private fun initialTarget(entry: HomeEntry, source: DragSource): DropPosition? = when (source) {
        DragSource.Library -> null
        DragSource.Folder -> openFolder?.let { folder ->
            DropPosition.InFolder(folder.id, folder.apps.indexOfFirst { it.key == entry.id }.coerceAtLeast(0))
        }
        DragSource.Dock -> DropPosition.Dock(state.dock.indexOfFirst { it.id == entry.id }.coerceAtLeast(0))
        DragSource.Page -> state.pages.withIndex().firstNotNullOfOrNull { (page, items) ->
            items.indexOfFirst { it.id == entry.id }.takeIf { it >= 0 }?.let { DropPosition.PageCell(page, state.cells[entry.id] ?: it) }
        }
    }

    private fun updateTarget(s: DragSession) {
        val p = s.hotspot
        if (pageMap.library && currentPage == pageMap.homeCount) {
            setMerge(null)
            val position = if (s.entry is AppEntry) libraryTargets.values.lastOrNull()?.invoke(p) else null
            reorderJob?.cancel()
            pendingTarget = position
            target = position
            handlePageEdge(s.pointer)
            return
        }
        // A library destination must never survive a return to a home page.
        if (target is DropPosition.Library) target = null
        if (pendingTarget is DropPosition.Library) retarget(null)
        if (openFolder == null && pageGrid == null) return

        // 1. Inside an open folder.
        val folder = openFolder
        val panel = folderPanel
        if (folder != null && panel != null) {
            if (panel.contains(p)) {
                leaveFolderJob?.cancel()
                leaveFolderJob = null
                folderGrid?.let { grid ->
                    val visible = previewFolder(folder)
                    val cell = grid.cellAt(p) + folderPage * FOLDER_PAGE_SIZE
                    setMerge(null)
                    if (visible.getOrNull(cell) !is PlaceholderEntry) {
                        retarget(DropPosition.InFolder(folder.id, cell.coerceAtMost(visible.size - 1).coerceAtLeast(0)))
                    }
                }
            } else if (leaveFolderJob == null) {
                leaveFolderJob = scope.launch {
                    delay(LEAVE_FOLDER_DELAY_MS)
                    leaveFolderJob = null
                    callbacks.onLeaveFolder()
                }
            }
            return
        }

        // On the Today page nothing can be dropped (widgets there are arranged from the menu).
        if (currentPage < 0) {
            setMerge(null)
            retarget(null)
            return
        }

        // 2. Over the dock (widgets don't go there).
        val dock = dockBounds
        if (dock != null && p.y >= dock.top && s.entry !is PageWidgetEntry) {
            cancelEdgeFlip()
            updateDockTarget(s, dock, p)
            return
        }

        // 3. Over a home screen page.
        val grid = pageGrid ?: return
        // Page flipping follows the finger itself: that's what the user pushes against the edge.
        handlePageEdge(s.pointer)
        val pages = previewPages()
        val page = currentPage.coerceIn(0, pages.lastIndex)
        val visible = pages[page]
        val spans = visible.map { it.span }
        val positions = previewCells()
        val cells = packCells(spans, grid.grid, visible.map { positions[it.id] })
        val cell = grid.cellAt(p)
        // A widget lands where its card is, whichever cell the finger is on.
        val anchor = if (s.entry is PageWidgetEntry) grid.footprintCell(s.pointer - s.touchOffset, s.entry.span) else cell
        val destination = DropPosition.PageCell(page, boundedCell(anchor, s.entry.span, grid.grid))
        val underIndex = itemAtCell(spans, cells, cell, grid.grid)
        val under = underIndex?.let(visible::get)
        when {
            under == null -> {
                setMerge(null)
                retarget(destination)
            }
            under is PlaceholderEntry -> {
                setMerge(null)
                retarget(destination)
            }
            canMergeOnto(s.entry, under) && mergeDistance(s, grid, under, cells[underIndex]!!).let { (d, size) -> isOver(under, d, size) } -> {
                retarget(null)
                setMerge(under.id)
            }
            else -> {
                setMerge(null)
                retarget(destination, REORDER_OVER_ICON_DELAY_MS, untilRest = true)
            }
        }
    }

    /** Refreshes the destination after a page handoff, even if the finger is held still. */
    fun updatePageGrid(grid: GridGeometry) {
        pageGrid = grid
        session?.takeIf { it.active }?.let(::updateTarget)
    }

    /** Rechecks stationary drags after the library lays out or scrolls its cells. */
    fun refreshTarget() {
        session?.takeIf { it.active }?.let(::updateTarget)
    }

    private fun updateDockTarget(s: DragSession, dock: Rect, p: Offset) {
        val others = state.dock.filter { it.id != s.entry.id }
        val canInsert = s.source == DragSource.Dock || others.size < dockCapacity
        val slots = if (canInsert) others.size + 1 else others.size
        // Distance from the dock's start edge: slot 0 is on the right in RTL.
        val x = if (rtl) dock.right - p.x else p.x - dock.left
        val slotWidth = dock.width / slots.coerceAtLeast(1)
        val slot = (x / slotWidth).toInt().coerceIn(0, (slots - 1).coerceAtLeast(0))

        // Hovering the middle of a dock icon makes a folder there too.
        val preview = previewDock()
        val previewWidth = dock.width / preview.size.coerceAtLeast(1)
        val under = preview.getOrNull((x / previewWidth).toInt())
        val underCenterX = (preview.indexOf(under) + 0.5f) * previewWidth
        if (under != null && canMergeOnto(s.entry, under) &&
            isOver(under, kotlin.math.abs(x - underCenterX), pageGrid?.iconSize ?: dock.height)
        ) {
            retarget(null)
            setMerge(under.id)
            return
        }
        setMerge(null)
        val overIcon = under != null && under !is PlaceholderEntry
        if (canInsert) retarget(DropPosition.Dock(slot), if (overIcon) REORDER_OVER_ICON_DELAY_MS else REORDER_DELAY_MS, overIcon)
    }

    /**
     * Icons make room once the slot under the finger has stayed the same for a short dwell,
     * like iOS: sweeping across the grid doesn't shuffle everything, a slow drag reflows as it
     * goes. Over an icon ([untilRest]) the finger must also stop, so icons don't slide away
     * before you reach their center to make a folder. `null` cancels a pending change.
     */
    private fun retarget(position: DropPosition?, delayMs: Long = REORDER_DELAY_MS, untilRest: Boolean = false) {
        val pointer = session?.pointer ?: return
        val moved = untilRest && (pointer - restPoint).getDistance() > slopPx / 2
        if (moved || position != pendingTarget) restPoint = pointer
        if (position == pendingTarget && !moved) return
        pendingTarget = position
        reorderJob?.cancel()
        if (position == null || position == target) return
        reorderJob = scope.launch {
            delay(delayMs)
            target = position
        }
    }

    /**
     * Whether the dragged icon (or widget) covers an item whose center is [distance] px away. The zone is
     * big (the icons overlap by about half) and sticky: once a target is picked, it is
     * released only past a wider radius, so small finger jitter never flips the intent.
     */
    private fun isOver(under: HomeEntry, distance: Float, iconSize: Float): Boolean =
        distance < iconSize * if (under.id == mergeCandidate) MERGE_EXIT_RADIUS else MERGE_ENTER_RADIUS

    /** Dropping into an existing folder or stack arms at once; two apps or two widgets need a short hover. */
    private fun setMerge(id: String?) {
        if (id == mergeCandidate) return
        mergeCandidate = id
        mergeJob?.cancel()
        mergeArmed = id != null && mergesAtOnce(previewEntry(id))
        if (id != null && !mergeArmed) {
            mergeJob = scope.launch {
                delay(MERGE_DELAY_MS)
                mergeArmed = true
            }
        }
    }

    private fun previewEntry(id: String): HomeEntry? =
        state.dock.firstOrNull { it.id == id } ?: state.pages.firstNotNullOfOrNull { page -> page.firstOrNull { it.id == id } }

    /** Holding the item at the left/right screen edge flips to the neighbor page. */
    private fun handlePageEdge(p: Offset) {
        if (pointers.hasSecondary) { cancelEdgeFlip(); return }
        val side = when {
            p.x < edgePx -> -1
            p.x > screenWidth - edgePx -> 1
            else -> 0
        }
        // The pager runs from right to left in RTL.
        val direction = if (rtl) -side else side
        if (direction == 0) {
            cancelEdgeFlip()
            return
        }
        if (edgeJob != null) return
        edgeJob = scope.launch {
            while (true) {
                delay(EDGE_FLIP_DELAY_MS)
                val next = pageMap.dragNeighbor(currentPage, direction, session?.entry is AppEntry) ?: break
                callbacks.onFlipPage(next)
                currentPage = next
                session?.let { if (it.active) updateTarget(it) }
            }
            edgeJob = null
        }
    }

    private fun cancelEdgeFlip() {
        edgeJob?.cancel()
        edgeJob = null
    }

    /** Ends the drag without dropping (the layout was locked): the item stays where it was, nothing is saved. */
    fun cancel() {
        dropOrigin = null
        reset()
    }

    private fun drop(s: DragSession) {
        val position = if (mergeArmed) mergeCandidate?.let { DropPosition.Merge(it) } else null
        // Land on the slot under the item, even if the icons haven't made room yet.
        val finalPosition = position ?: pendingTarget ?: target
        dropOrigin = s.entry.id to (s.pointer - s.touchOffset)
        reset()
        if (finalPosition != null) callbacks.onDrop(s.entry.id, finalPosition)
    }

    private fun reset() {
        pointers.reset()
        reorderJob?.cancel()
        pendingTarget = null
        session = null
        target = null
        setMerge(null)
        cancelEdgeFlip()
        leaveFolderJob?.cancel()
        leaveFolderJob = null
    }

    companion object {
        /** The dragged icon's center this close to an icon center (fraction of icon size) targets a folder. */
        private const val MERGE_ENTER_RADIUS = 0.55f
        /** A picked folder target is kept until the dragged icon moves this far away. */
        private const val MERGE_EXIT_RADIUS = 0.8f
        private const val MERGE_DELAY_MS = 200L
        /** Dwell on an empty slot before icons make room. */
        private const val REORDER_DELAY_MS = 70L
        /** Rest needed to push aside an icon the dragged one only partly covers. */
        private const val REORDER_OVER_ICON_DELAY_MS = 220L
        private const val EDGE_FLIP_DELAY_MS = 550L
        private const val LEAVE_FOLDER_DELAY_MS = 350L
    }
}
