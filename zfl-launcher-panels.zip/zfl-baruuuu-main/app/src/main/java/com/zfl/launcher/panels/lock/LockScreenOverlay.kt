package com.zfl.launcher.panels.lock

import android.content.Intent
import android.provider.MediaStore
import android.text.format.DateFormat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zfl.launcher.R
import com.zfl.launcher.panels.PanelController
import com.zfl.launcher.panels.control.ControlState
import com.zfl.launcher.panels.control.SystemControls
import com.zfl.launcher.panels.control.startQuietly
import com.zfl.launcher.panels.notifications.CenterNotification
import com.zfl.launcher.panels.notifications.NotificationCard
import com.zfl.launcher.panels.verticalPanelDrag
import kotlinx.coroutines.delay
import java.util.Date

private const val MAX_STACK = 3

/**
 * The Lock Screen view: wallpaper, large clock and date, the latest notifications, flashlight
 * and camera shortcuts, and a home indicator. It is a layer of the launcher and is NOT the
 * system lock screen: it adds no security and unlocking is a swipe. Android does not let a
 * launcher replace or bypass the secure lock screen, and this view does not try to.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun LockScreenOverlay(
    controller: PanelController,
    controls: SystemControls,
    controlState: ControlState,
    wallpaper: ImageBitmap?,
    notifications: List<CenterNotification>,
    hideContent: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    // Wakes exactly at each minute change, so the clock never ticks while the display is idle.
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L)
        }
    }
    val locale = LocalConfiguration.current.locales[0]
    val time = remember(now, locale) {
        val pattern = DateFormat.getBestDateTimePattern(locale, if (DateFormat.is24HourFormat(context)) "Hm" else "hm")
        java.text.SimpleDateFormat(pattern, locale).format(Date(now)).replace(Regex("\\s?[AaPp][Mm]$"), "")
    }
    val date = remember(now, locale) {
        java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(locale, "EEEEMMMMd"), locale).format(Date(now))
    }

    Box(
        modifier
            .fillMaxSize()
            .graphicsLayer {
                val shown = controller.lockFraction
                translationY = -(1f - shown) * size.height
                alpha = (shown * 3f).coerceIn(0f, 1f)
            }
            .background(Color.Black)
            .verticalPanelDrag(
                accepts = { true },
                onStart = {},
                onDrag = { controller.dragLock(it) },
                onEnd = controller::releaseLock,
            ),
    ) {
        if (wallpaper != null) {
            Image(wallpaper, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Black.copy(alpha = 0.55f))),
            ),
        )
        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBarsIgnoringVisibility).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(48.dp))
            Text(date, color = Color.White.copy(alpha = 0.9f), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(time, color = Color.White, fontSize = 92.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                notifications.take(MAX_STACK).forEach { item ->
                    NotificationCard(item, hideContent, onClick = controller::unlock)
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                RoundShortcut(
                    Icons.Rounded.FlashlightOn, stringResource(R.string.control_flashlight), controlState.torch,
                ) { if (controlState.torchAvailable) controls.setTorch(!controlState.torch) }
                RoundShortcut(Icons.Rounded.CameraAlt, stringResource(R.string.control_camera), false) {
                    context.startQuietly(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                }
            }
            Box(
                Modifier
                    .padding(top = 20.dp, bottom = 10.dp)
                    .width(140.dp).height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.7f))
                    .clickable(role = Role.Button, onClickLabel = stringResource(R.string.lock_screen_unlock), onClick = controller::unlock),
            )
        }
    }
}

@Composable
private fun RoundShortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(if (active) Color.White else Color.Black.copy(alpha = 0.4f))
            .clickable(role = Role.Button, onClickLabel = label, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(24.dp))
    }
}
