package com.zfl.launcher.panels.control

import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.zfl.launcher.island.IslandAccess

/** The media session the Control Center shows and drives. */
class NowPlaying(
    val title: String,
    val artist: String?,
    val playing: Boolean,
    val artwork: ImageBitmap?,
    private val controller: MediaController,
) {
    fun playPause() = if (playing) controller.transportControls.pause() else controller.transportControls.play()
    fun next() = controller.transportControls.skipToNext()
    fun previous() = controller.transportControls.skipToPrevious()
}

/**
 * The playing session, or the first one, from the media sessions Android lists for apps with
 * notification access. Null without that access (a [SecurityException]) or without a session.
 * Called while the panel is visible only; no listener stays registered.
 */
fun readNowPlaying(context: Context): NowPlaying? {
    val manager = context.getSystemService(MediaSessionManager::class.java) ?: return null
    val sessions = runCatching { manager.getActiveSessions(IslandAccess.component(context)) }.getOrNull().orEmpty()
    val controller = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        ?: sessions.firstOrNull() ?: return null
    val metadata = controller.metadata ?: return null
    val title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
    val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
    return NowPlaying(
        title = title,
        artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST),
        playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING,
        artwork = art?.asImageBitmap(),
        controller = controller,
    )
}
