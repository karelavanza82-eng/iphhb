package com.zfl.launcher.panels.control

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AirplanemodeActive
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.ScreenLockRotation
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zfl.launcher.R
import com.zfl.launcher.island.IslandAccess
import kotlinx.coroutines.delay

/** What the Control Center asks of the host: closing itself and the two other panels. */
internal class ControlCenterActions(
    val close: () -> Unit,
    val openNotifications: () -> Unit,
    val showLockScreen: () -> Unit,
    val notificationCenterEnabled: Boolean,
)

private val Gap = 12.dp
private val SideMargin = 20.dp
private val MaxWidth = 420.dp

/**
 * The Control Center grid. Tiles reflect [SystemControls.state]; the ones Android does not let
 * a launcher switch open the system's own panel, and the ones that need a grant send the user
 * to the screen where it is given.
 */
@Composable
internal fun ControlCenterPanel(controls: SystemControls, actions: ControlCenterActions, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val state by controls.state.collectAsStateWithLifecycle()
    var playing by remember { mutableStateOf<NowPlaying?>(null) }
    var mediaAccess by remember { mutableStateOf(IslandAccess.read(context).notifications) }
    LaunchedEffect(Unit) {
        while (true) {
            mediaAccess = IslandAccess.read(context).notifications
            playing = if (mediaAccess) readNowPlaying(context) else null
            delay(MEDIA_POLL_MS)
        }
    }

    val width = minOf(LocalConfiguration.current.screenWidthDp.dp, MaxWidth) - SideMargin * 2
    val unit = (width - Gap * 3) / 4
    fun span(cells: Int): Dp = unit * cells + Gap * (cells - 1)
    val tile = Modifier.size(unit)
    var askedForWrite by remember { mutableStateOf(false) }
    LaunchedEffect(state.canWriteSettings) { askedForWrite = false }

    fun open(intent: Intent) {
        if (!context.startQuietly(intent)) Toast.makeText(context, R.string.control_unavailable, Toast.LENGTH_SHORT).show()
    }
    fun needGrant(grant: ControlGrant) {
        val message = if (grant == ControlGrant.WriteSettings) R.string.control_need_write_settings else R.string.control_need_focus_access
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        open(controls.grantIntent(grant))
    }
    fun launchAndClose(intent: Intent) {
        open(intent)
        actions.close()
    }

    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.width(width), verticalArrangement = Arrangement.spacedBy(Gap)) {
            Row(horizontalArrangement = Arrangement.spacedBy(Gap)) {
                Box(
                    Modifier.size(span(2)).clip(RoundedCornerShape(26.dp)).background(Color.White.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    val button = Modifier.size(unit * 0.82f)
                    Column(verticalArrangement = Arrangement.spacedBy(Gap)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(Gap)) {
                            ControlTile(Icons.Rounded.AirplanemodeActive, stringResource(R.string.control_airplane), state.airplane, ControlColors.Orange,
                                { open(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }, button, round = true)
                            ControlTile(Icons.Rounded.Wifi, stringResource(R.string.control_wifi), state.wifi, ControlColors.Blue,
                                { open(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }, button, round = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(Gap)) {
                            ControlTile(Icons.Rounded.Bluetooth, stringResource(R.string.control_bluetooth), state.bluetooth, ControlColors.Blue,
                                { open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, button, round = true)
                            ControlTile(Icons.Rounded.FlashlightOn, stringResource(R.string.control_flashlight), state.torch, ControlColors.White,
                                { if (state.torchAvailable) controls.setTorch(!state.torch) else Toast.makeText(context, R.string.control_flashlight_unavailable, Toast.LENGTH_SHORT).show() },
                                button, round = true)
                        }
                    }
                }
                MediaCard(playing, mediaAccess, onAllowAccess = { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.size(span(2)))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Gap), modifier = Modifier.height(span(2))) {
                Column(verticalArrangement = Arrangement.spacedBy(Gap)) {
                    ControlTile(Icons.Rounded.ScreenLockRotation, stringResource(R.string.control_rotation_lock), state.rotationLocked, ControlColors.Red,
                        { controls.toggleRotationLock()?.let(::needGrant) }, tile)
                    ControlTile(Icons.Rounded.Bedtime, stringResource(R.string.control_focus), state.focus, ControlColors.Purple,
                        { controls.toggleFocus()?.let(::needGrant) }, tile)
                }
                VerticalControlSlider(state.brightness, Icons.Rounded.WbSunny, stringResource(R.string.control_brightness),
                    { value ->
                        // One request per drag, not one per touch event.
                        if (state.canWriteSettings) controls.setBrightness(value)
                        else if (!askedForWrite) { askedForWrite = true; needGrant(ControlGrant.WriteSettings) }
                    }, Modifier.width(unit).fillMaxHeight())
                VerticalControlSlider(state.volume, Icons.Rounded.VolumeUp, stringResource(R.string.control_volume),
                    controls::setVolume, Modifier.width(unit).fillMaxHeight())
                Column(verticalArrangement = Arrangement.spacedBy(Gap)) {
                    if (actions.notificationCenterEnabled) {
                        ControlTile(Icons.Rounded.Notifications, stringResource(R.string.notification_center_title), false, ControlColors.Blue,
                            actions.openNotifications, tile, showsState = false)
                    } else Spacer(tile)
                    ControlTile(Icons.Rounded.Lock, stringResource(R.string.lock_screen_title), false, ControlColors.Blue,
                        actions.showLockScreen, tile, showsState = false)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Gap)) {
                ControlTile(Icons.Rounded.Calculate, stringResource(R.string.control_calculator), false, ControlColors.White,
                    { launchAndClose(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)) }, tile, showsState = false)
                ControlTile(Icons.Rounded.Timer, stringResource(R.string.control_timer), false, ControlColors.White,
                    { launchAndClose(Intent(AlarmClock.ACTION_SHOW_TIMERS)) }, tile, showsState = false)
                ControlTile(Icons.Rounded.CameraAlt, stringResource(R.string.control_camera), false, ControlColors.White,
                    { launchAndClose(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, tile, showsState = false)
                ControlTile(Icons.Rounded.Settings, stringResource(R.string.control_settings), false, ControlColors.White,
                    { launchAndClose(Intent(Settings.ACTION_SETTINGS)) }, tile, showsState = false)
            }
        }
    }
}

/** Starts [intent] from the launcher; false when no app handles it. */
internal fun Context.startQuietly(intent: Intent): Boolean =
    runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess

private const val MEDIA_POLL_MS = 1000L
